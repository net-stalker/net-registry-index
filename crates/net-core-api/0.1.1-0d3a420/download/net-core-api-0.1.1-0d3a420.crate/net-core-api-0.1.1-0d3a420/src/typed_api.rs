pub trait Typed {
    fn get_data_type() -> &'static str where Self : Sized;
    fn get_type(&self) -> &str;
}