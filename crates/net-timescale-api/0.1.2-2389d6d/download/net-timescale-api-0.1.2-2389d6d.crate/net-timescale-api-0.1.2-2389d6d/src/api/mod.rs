pub mod dashboard;

pub mod network_bandwith;
pub mod network_graph;
pub mod network_packet;

pub mod requests;