pub mod dashboard;

pub mod network_bandwidth;
pub mod network_graph;
pub mod network_packet;

pub mod requests;