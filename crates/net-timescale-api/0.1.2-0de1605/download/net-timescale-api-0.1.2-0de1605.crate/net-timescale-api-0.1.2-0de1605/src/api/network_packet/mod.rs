#[allow(clippy::module_inception)]
pub mod network_packet;