//TODO: Rewrite all the inbound ion structs encode to `write_blob(*.encode())`

pub mod dashboard;

//TODO: Add network prefix
pub mod bandwidth_per_endpoint;

pub mod network_bandwidth;
pub mod network_graph;
pub mod network_packet;
