use std::net::SocketAddr;

use rustls_pki_types::CertificateDer;

use crate::quinn::common::make_client_endpoint;

use super::endpoint::ClientQuicEndpoint;

#[derive(Default)]
pub struct ClientQuicConnectorBuilder {
    pub certs: Option<Vec<CertificateDer<'static>>>,
    pub addr: Option<SocketAddr>,
}

impl ClientQuicConnectorBuilder {
    pub fn with_cert(mut self, cert: CertificateDer<'static>) -> Self {
        if self.certs.is_none() {
            self.certs = Some(vec![]);
        }
        self.certs.as_mut().unwrap().push(cert);
        self
    }

    pub fn with_addr(mut self, addr: SocketAddr) -> Self {
        self.addr = Some(addr);
        self
    }

    // TODO: create error type for not returning a String as an error
    pub fn build(self) -> Result<ClientQuicEndpoint, String> {
        let endpoint = make_client_endpoint(
            self.addr.unwrap(),
            self.certs
        );

        if let Err(e) = endpoint {
            return Err(format!("error: {:?}", e));
        }
        let endpoint = endpoint.unwrap();

        Ok(ClientQuicEndpoint::new(endpoint))
    }
}