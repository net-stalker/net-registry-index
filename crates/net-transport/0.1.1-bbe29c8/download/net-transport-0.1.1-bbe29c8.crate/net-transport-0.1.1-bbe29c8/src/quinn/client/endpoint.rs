use std::net::SocketAddr;

use quinn::Endpoint;

use crate::quinn::connection::QuicConnection;

use super::builder::ClientQuicEndpointBuilder;

pub struct ClientQuicEndpoint {
    endpoint: Endpoint,
}

impl ClientQuicEndpoint {
    pub fn new(
        endpoint: Endpoint,
    ) -> Self {
        Self {
            endpoint,
        }
    }

    pub fn builder() -> ClientQuicEndpointBuilder {
        ClientQuicEndpointBuilder::default()
    }

    pub async fn connect(
        &mut self,
        addr: SocketAddr,
        application: &str,
    ) -> Result<QuicConnection, String> {
        let connecting = self
            .endpoint
            .connect(addr, application);
        
        if let Err(e) = connecting {
            return Err(format!("error: {:?}", e));
        }
        let connection = connecting.unwrap().await;
        
        if let Err(e) = connection {
            return Err(format!("error: {:?}", e));
        }
        let connection = connection.unwrap();

        Ok(connection.into())
    }
}