use quinn::Endpoint;

use crate::quinn::connection::QuicConnection;

use super::builder::ServerQuicEndpointBuilder;

pub struct ServerQuicEndpoint {
    endpoint: Endpoint,
}

impl ServerQuicEndpoint {
    pub fn new(
        endpoint: Endpoint,
    ) -> Self {
        Self {
            endpoint,
        }
    }

    pub fn builder() -> ServerQuicEndpointBuilder {
        ServerQuicEndpointBuilder::default()
    }

    pub async fn accept_client_connection(
        &mut self,
    ) -> Result<QuicConnection, String> {
        let client_connecting = self.endpoint.accept().await;
        
        if client_connecting.is_none() {
            return Err("error: There is no client pending connection".to_string());
        }
        let client_connection = client_connecting.unwrap().await;

        if let Err(e) = client_connection {
            return Err(format!("error: {:?}", e));
        }
        let connection = client_connection.unwrap();

        Ok(connection.into())
    }
}