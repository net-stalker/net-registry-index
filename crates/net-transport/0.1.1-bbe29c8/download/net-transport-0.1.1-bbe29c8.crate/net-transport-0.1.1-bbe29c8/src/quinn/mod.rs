pub mod certs;
pub mod common;

pub mod connection;

pub mod client;
pub mod server;

const MESSAGE_SIZE_LIMIT: usize = u32::MAX as usize;

#[cfg(test)]
mod tests {
    use serial_test::serial;

    use crate::quinn::server::builder::ServerQuicEndpointBuilder;
    use crate::quinn::client::builder::ClientQuicEndpointBuilder;

    const TEST_SERVER_ADDRESS: &str = "127.0.0.1:4545";
    const TEST_CLIENT_ADDRESS: &str = "0.0.0.0:0";

    const TEST_SERVER_APPLICATION: &str = "localhost";

    const DATA_TO_SEND: &[u8] = &[0, 0, 0, 0];

    const AMOUNT_OF_CLIENTS: usize = 32;

    #[tokio::test]
    #[serial]
    async fn mono_client_connection_test() {
        let server_task = tokio::spawn(async {
            let server_connector = ServerQuicEndpointBuilder::default()
                .with_addr(TEST_SERVER_ADDRESS.parse().unwrap())
                .build();

            assert!(server_connector.is_ok());
            let mut server_connector = server_connector.unwrap();

            let connection_result = server_connector.accept_client_connection().await;
            assert!(connection_result.is_ok());
        });

        let client_task = tokio::spawn(async {
            let client_connector = ClientQuicEndpointBuilder::default()
                .with_addr(TEST_CLIENT_ADDRESS.parse().unwrap())
                .build();

            assert!(client_connector.is_ok());
            let mut client_connector = client_connector.unwrap();

            let connection_result = client_connector.connect(TEST_SERVER_ADDRESS.parse().unwrap(), TEST_SERVER_APPLICATION).await;
            assert!(connection_result.is_ok());
        });

        let _ = tokio::try_join!(client_task, server_task);
    }

    #[tokio::test]
    #[serial]
    async fn multiple_client_connection_test() {
        let server_task = tokio::spawn(async {
            let server_connector = ServerQuicEndpointBuilder::default()
                .with_addr(TEST_SERVER_ADDRESS.parse().unwrap())
                .build();

            assert!(server_connector.is_ok());
            let mut server_connector = server_connector.unwrap();
            
            for _ in 0..AMOUNT_OF_CLIENTS {
                let connection_result = server_connector.accept_client_connection().await;
                assert!(connection_result.is_ok());
            }
        });

        let mut client_tasks = Vec::new();
        for _ in 0..AMOUNT_OF_CLIENTS {
            let client_task = tokio::spawn(async {
                let client_connector = ClientQuicEndpointBuilder::default()
                .with_addr(TEST_CLIENT_ADDRESS.parse().unwrap())
                .build();

                assert!(client_connector.is_ok());
                let mut client_connector = client_connector.unwrap();

                let connection_result = client_connector.connect(TEST_SERVER_ADDRESS.parse().unwrap(), TEST_SERVER_APPLICATION).await;
                assert!(connection_result.is_ok());
            });
            client_tasks.push(client_task);
        }
        
        let mut tasks = Vec::new();
        tasks.push(server_task);
        tasks.append(&mut client_tasks);
        let _ = futures::future::try_join_all(tasks).await;
    }

    #[tokio::test]
    #[serial]
    async fn mono_client_echo_server_test() {
        let server_task = tokio::spawn(async {
            let server_connector = ServerQuicEndpointBuilder::default()
                .with_addr(TEST_SERVER_ADDRESS.parse().unwrap())
                .build();

            assert!(server_connector.is_ok());
            let mut server_connector = server_connector.unwrap();

            let connection_result = server_connector.accept_client_connection().await;
            assert!(connection_result.is_ok());

            let mut client_connection = connection_result.unwrap();

            let receive_result = client_connection.receive_reliable().await;
            assert!(receive_result.is_ok());
            let recieve_result = receive_result.unwrap();
            assert_eq!(DATA_TO_SEND, recieve_result);

            let send_result = client_connection.send_all_reliable(&recieve_result).await;
            assert!(send_result.is_ok());
        });

        let client_task = tokio::spawn(async {
            let client_connector = ClientQuicEndpointBuilder::default()
                .with_addr(TEST_CLIENT_ADDRESS.parse().unwrap())
                .build();

            assert!(client_connector.is_ok());
            let mut client_connector = client_connector.unwrap();

            let connection_result = client_connector.connect(TEST_SERVER_ADDRESS.parse().unwrap(), TEST_SERVER_APPLICATION).await;
            assert!(connection_result.is_ok());

            let mut server_connection = connection_result.unwrap();

            let send_result = server_connection.send_all_reliable(DATA_TO_SEND).await;
            assert!(send_result.is_ok());

            let receive_result = server_connection.receive_reliable().await;
            assert!(receive_result.is_ok());
            let recieve_result = receive_result.unwrap();
            assert_eq!(DATA_TO_SEND, recieve_result);
        });

        let _ = tokio::try_join!(client_task, server_task);
    }

    #[tokio::test]
    #[serial]
    async fn multiple_client_sync_echo_server_test() {
        let server_task = tokio::spawn(async {
            let server_connector = ServerQuicEndpointBuilder::default()
                .with_addr(TEST_SERVER_ADDRESS.parse().unwrap())
                .build();

            assert!(server_connector.is_ok());
            let mut server_connector = server_connector.unwrap();

            for _ in 0..AMOUNT_OF_CLIENTS {
                let connection_result = server_connector.accept_client_connection().await;
                assert!(connection_result.is_ok());
    
                let mut client_connection = connection_result.unwrap();
    
                let receive_result = client_connection.receive_reliable().await;
                assert!(receive_result.is_ok());
                let recieve_result = receive_result.unwrap();
                assert_eq!(DATA_TO_SEND, recieve_result);
    
                let send_result = client_connection.send_all_reliable(&recieve_result).await;
                assert!(send_result.is_ok());
            }
        });

        let mut client_tasks = Vec::new();
        for _ in 0..AMOUNT_OF_CLIENTS {
            let client_task = tokio::spawn(async {
                let client_connector = ClientQuicEndpointBuilder::default()
                .with_addr(TEST_CLIENT_ADDRESS.parse().unwrap())
                .build();

                assert!(client_connector.is_ok());
                let mut client_connector = client_connector.unwrap();

                let connection_result = client_connector.connect(TEST_SERVER_ADDRESS.parse().unwrap(), TEST_SERVER_APPLICATION).await;
                assert!(connection_result.is_ok());

                let mut server_connection = connection_result.unwrap();

                let send_result = server_connection.send_all_reliable(DATA_TO_SEND).await;
                assert!(send_result.is_ok());
    
                let receive_result = server_connection.receive_reliable().await;
                assert!(receive_result.is_ok());
                let recieve_result = receive_result.unwrap();
                assert_eq!(DATA_TO_SEND, recieve_result);
            });
            client_tasks.push(client_task);
        }
        
        let mut tasks = Vec::new();
        tasks.push(server_task);
        tasks.append(&mut client_tasks);
        let task_results = futures::future::try_join_all(tasks).await;

        assert!(task_results.is_ok());
    }

    #[tokio::test]
    #[serial]
    async fn multiple_client_async_echo_server_test() {
        let server_task = tokio::spawn(async {
            let server_connector = ServerQuicEndpointBuilder::default()
                .with_addr(TEST_SERVER_ADDRESS.parse().unwrap())
                .build();

            assert!(server_connector.is_ok());
            let mut server_connector = server_connector.unwrap();

            for _ in 0..AMOUNT_OF_CLIENTS {
                let connection_result = server_connector.accept_client_connection().await;
                assert!(connection_result.is_ok());
    
                let mut client_connection = connection_result.unwrap();
                
                //TODO: asserts here will not cause to panic!
                tokio::spawn(async move {
                    let receive_result = client_connection.receive_reliable().await;
                    assert!(receive_result.is_ok());
                    let recieve_result = receive_result.unwrap();
                    assert_eq!(DATA_TO_SEND, recieve_result);
        
                    let send_result = client_connection.send_all_reliable(&recieve_result).await;
                    assert!(send_result.is_ok());
                });
            }
        });

        let mut client_tasks = Vec::new();
        for _ in 0..AMOUNT_OF_CLIENTS {
            let client_task = tokio::spawn(async {
                let client_connector = ClientQuicEndpointBuilder::default()
                .with_addr(TEST_CLIENT_ADDRESS.parse().unwrap())
                .build();

                assert!(client_connector.is_ok());
                let mut client_connector = client_connector.unwrap();

                let connection_result = client_connector.connect(TEST_SERVER_ADDRESS.parse().unwrap(), TEST_SERVER_APPLICATION).await;
                assert!(connection_result.is_ok());

                let mut server_connection = connection_result.unwrap();

                let send_result = server_connection.send_all_reliable(DATA_TO_SEND).await;
                assert!(send_result.is_ok());
    
                let receive_result = server_connection.receive_reliable().await;
                assert!(receive_result.is_ok());
                let recieve_result = receive_result.unwrap();
                assert_eq!(DATA_TO_SEND, recieve_result);
            });
            client_tasks.push(client_task);
        }
        
        let mut tasks = Vec::new();
        tasks.push(server_task);
        tasks.append(&mut client_tasks);
        let task_results = futures::future::try_join_all(tasks).await;

        assert!(task_results.is_ok());
    }
}