use std::net::SocketAddr;

use rustls_pki_types::CertificateDer;
use rustls_pki_types::PrivatePkcs1KeyDer;

use crate::quinn::common::make_server_endpoint;

use super::endpoint::ServerQuicEndpoint;

#[derive(Default)]
pub struct ServerQuicEndpointBuilder {
    pub certs: Option<Vec<CertificateDer<'static>>>,
    pub key: Option<PrivatePkcs1KeyDer<'static>>,
    pub addr: Option<SocketAddr>,
    pub application: Option<String>,
}

impl ServerQuicEndpointBuilder {
    pub fn with_cert(mut self, cert: CertificateDer<'static>) -> Self {
        if self.certs.is_none() {
            self.certs = Some(vec![]);
        }
        self.certs.as_mut().unwrap().push(cert);
        self
    }

    pub fn with_key(mut self, key: PrivatePkcs1KeyDer<'static>) -> Self {
        self.key = Some(key);
        self
    }

    pub fn with_addr(mut self, addr: SocketAddr) -> Self {
        self.addr = Some(addr);
        self
    }

    // TODO: create error type for not returning a String as an error
    pub fn build(self) -> Result<ServerQuicEndpoint, String> {
        let endpoint = make_server_endpoint(
            self.addr.unwrap(),
            self.certs,
            self.key,
        // TODO: replace this unwrap with a proper error
        ).unwrap();

        Ok(ServerQuicEndpoint::new(endpoint))
    }
}