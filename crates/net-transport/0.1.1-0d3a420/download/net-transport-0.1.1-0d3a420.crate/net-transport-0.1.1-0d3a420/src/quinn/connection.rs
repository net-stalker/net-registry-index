use quinn::Connection;
use quinn::RecvStream;
use quinn::SendStream;

use super::MESSAGE_SIZE_LIMIT;

pub struct QuicConnection {
    connection: Connection
}

impl From<Connection> for QuicConnection {
    fn from(connection: Connection) -> Self {
        Self {
            connection
        }
    }
}

impl QuicConnection {
    pub fn new(
        connection: Connection
    ) -> Self {
        Self {
            connection
        }
    }

    pub async fn open_uni_channel(
        &mut self,
    ) -> Result<SendStream, String> {
        let channel = self.connection.open_uni().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }
        let channel = channel.unwrap();
        
        Ok(channel)
    }

    pub async fn accept_uni_channel(
        &mut self,
    ) -> Result<RecvStream, String> {
        let channel = self.connection.accept_uni().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }
        let channel = channel.unwrap();
        
        Ok(channel)
    }

    pub async fn open_bi_channel(
        &mut self,
    ) -> Result<(SendStream, RecvStream), String> {
        let channel = self.connection.open_bi().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }
        let channel = channel.unwrap();

        Ok(channel)
    }

    pub async fn accept_bi_channel(
        &mut self,
    ) -> Result<(SendStream, RecvStream), String> {
        let channel = self.connection.accept_bi().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }
        let channel = channel.unwrap();
        
        Ok(channel)
    }

    pub async fn send_reliable(
        &mut self,
        data: &[u8]
    ) -> Result<usize, String> {
        let channel = self.open_uni_channel().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }

        let mut channel = channel.unwrap();
        
        let write_result = channel.write(data).await;
        if let Err(e) = write_result {
            return Err(format!("error: {:?}", e));
        }

        let write_result = write_result.unwrap();

        let finish = channel.finish().await;
        if let Err(e) = finish {
            return Err(format!("error: {:?}", e));
        }

        Ok(write_result)
    }

// This method is simular to ['send_reliable()'], but is guaranteed for whole data to be sent
    pub async fn send_all_reliable(
        &mut self,
        data: &[u8]
    ) -> Result<(), String> {
        let channel = self.open_uni_channel().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }

        let mut channel = channel.unwrap();

        let write_result = channel.write_all(data).await;
        if let Err(e) = write_result {
            return Err(format!("error: {:?}", e));
        }

        let finish = channel.finish().await;
        if let Err(e) = finish {
            return Err(format!("error: {:?}", e));
        }
        
        drop(channel);

        Ok(())
    }

    pub async fn receive_reliable(
        &mut self,
    ) -> Result<Vec<u8>, String> {
        let channel = self.accept_uni_channel().await;
        if let Err(e) = channel {
            return Err(format!("error: {:?}", e));
        }
        
        let mut channel = channel.unwrap();

        let read_result = channel.read_to_end(MESSAGE_SIZE_LIMIT).await;
        if let Err(e) = read_result {
            return Err(format!("error: {:?}", e));
        }
        let read_result = read_result.unwrap();

        drop(channel);

        Ok(read_result)
    }
}