use std::fmt::{Debug, Formatter};

use serde::{Deserialize, Serialize};
use toml::to_string;

use net_config::NetConfig;

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct HubConnector {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq, NetConfig)]
pub struct Config {
    pub(crate) hub_connector: HubConnector,
}

#[cfg(test)]
mod tests {
    use std::env;
    use super::*;

    #[test]
    fn expected_load_config() {
        let config = Config::builder()
            .with_config_dir(".config".to_string())
            .build();

        let expected_config = Config {
            hub_connector: HubConnector {
                addr: "tcp://0.0.0.0:5556".to_string(),
            },
        };

        assert_eq!(config.unwrap(), expected_config);

        env::set_var("NET_HUB_CONNECTOR.ADDR", "tcp://localhost:5556");

        let config = Config::builder().build();

        let expected_config = Config {
            hub_connector: HubConnector {
                addr: "tcp://localhost:5556".to_string(),
            },
        };

        assert_eq!(config.unwrap(), expected_config);
    }
}
