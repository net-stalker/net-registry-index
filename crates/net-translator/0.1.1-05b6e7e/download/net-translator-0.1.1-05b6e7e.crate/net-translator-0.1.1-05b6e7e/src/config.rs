use std::fmt::{Debug, Formatter};

use serde::{Deserialize, Serialize};
use toml::to_string;

use net_config::NetConfig;

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct HubConnectorReceiver {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct HubConnectorSender {
    pub(crate) addr: String,
}

#[derive(Debug, Deserialize, Serialize, PartialEq, Eq, NetConfig)]
pub struct Config {
    pub(crate) hub_connector_receiver: HubConnectorReceiver,
    pub(crate) hub_connector_sender: HubConnectorSender,
}

#[cfg(test)]
mod tests {
    use std::env;
    use super::*;

    #[test]
    fn expected_load_config() {
        let config = Config::builder()
            .with_config_dir(".config".to_string())
            .build();

        let expected_config = Config {
            hub_connector_receiver: HubConnectorReceiver {
                addr: "tcp://0.0.0.0:5556".to_string(),
            },
            hub_connector_sender: HubConnectorSender {
                addr: "tcp://0.0.0.0:5559".to_string(),
            }
        };

        assert_eq!(config.unwrap(), expected_config);

        env::set_var("NET_HUB_CONNECTOR_RECEIVER.ADDR", "tcp://localhost:5556");
        env::set_var("NET_HUB_CONNECTOR_SENDER.ADDR", "tcp://localhost:5559");

        let config = Config::builder().build();

        let expected_config = Config {
            hub_connector_sender: HubConnectorSender {
                addr: "tcp://localhost:5556".to_string(),
            },
            hub_connector_receiver: HubConnectorReceiver {
                addr: "tcp://localhost:5559".to_string(),
            },
        };

        assert_eq!(config.unwrap(), expected_config);
    }
}
