use std::rc::Rc;
use net_transport::dummy_command::DummyCommand;
use threadpool::ThreadPool;
use net_core::layer::NetComponent;

use net_transport::zmq::builders::dealer::ConnectorZmqDealerBuilder;
use net_transport::polling::zmq::ZmqPoller;
use net_transport::zmq::contexts::dealer::DealerContext;

use crate::command::decoder::DecoderCommand;
use crate::config::Config;

pub struct Translator {
    pool: ThreadPool,
    config: Config,
}

impl Translator {
    pub fn new(pool: ThreadPool, config: Config) -> Self {
        Self { pool, config }
    }
}

impl NetComponent for Translator {
    fn run(self) {
        log::info!("Run component");
        let dealer_context = DealerContext::default();
        self.pool.execute(move || {
            let hub_connector_sender = ConnectorZmqDealerBuilder::new(&dealer_context)
                .with_endpoint(self.config.hub_connector_sender.addr)
                .with_handler(Rc::new(DummyCommand {}))
                .build()
                .connect()
                .into_inner();

            let hub_connector_receiver = ConnectorZmqDealerBuilder::new(&dealer_context)
                .with_endpoint(self.config.hub_connector_receiver.addr)
                .with_handler(Rc::new(DecoderCommand::new(hub_connector_sender)))
                .build()
                .connect()
                .into_inner();
            
            ZmqPoller::new()
                .add(hub_connector_receiver)
                .poll(-1);
        });
    }
}
