#[allow(clippy::arc_with_non_send_sync)]
pub mod translator;