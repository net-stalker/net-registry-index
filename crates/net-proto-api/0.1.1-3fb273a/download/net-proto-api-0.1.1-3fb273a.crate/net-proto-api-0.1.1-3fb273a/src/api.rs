use crate::decoder_api::Decoder;
use crate::encoder_api::Encoder;
use crate::typed_api::Typed;
pub trait API : Decoder + Encoder + Typed {}