pub trait Typed {
    fn get_data_type(&self) -> &str;
}