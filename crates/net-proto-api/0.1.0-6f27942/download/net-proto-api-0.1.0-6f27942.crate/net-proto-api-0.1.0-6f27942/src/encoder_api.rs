pub trait Encoder {
    //TODO: Think of returning Result istread of walue for logs in future
    fn encode(&self) -> Vec<u8>;
}