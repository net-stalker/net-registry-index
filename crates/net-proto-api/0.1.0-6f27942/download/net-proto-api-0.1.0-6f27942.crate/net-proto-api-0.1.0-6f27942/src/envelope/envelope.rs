use ion_rs;
use ion_rs::IonWriter;
use ion_rs::IonReader;
use ion_rs::element::writer::TextKind;


#[derive(Debug, PartialEq, Eq)]
pub struct Envelope {
    group_id: Option<String>,
    agent_id: Option<String>,
    envelope_type: String,
    data: Vec<u8>,
}

impl Envelope {
    pub fn new( group_id: Option<&str>, agent_id: Option<&str>, envelope_type: &str, data: &[u8]) -> Self {
        Envelope {
            group_id: group_id.map(|id| id.into()),
            agent_id: agent_id.map(|id| id.into()),
            envelope_type: envelope_type.into(),
            data: data.into()
        }
    }

    pub fn get_group_id (&self) -> Result<&str, &str> {
        self.group_id
            .as_deref()
            .map_or_else(|| Err("There is no group_id provided"), Ok)
    }

    pub fn get_agent_id (&self) -> Result<&str, &str> {
        self.agent_id
            .as_deref()
            .map_or_else(|| Err("There is no agent_id provided"), Ok)
    }

    pub fn get_type (&self) -> &str {
        &self.envelope_type
    }

    pub fn get_data (&self) -> &[u8] {
        &self.data
    }
}

impl crate::encoder_api::Encoder for Envelope {
    fn encode(&self) -> Vec<u8> {
        let buffer: Vec<u8> = Vec::new();

        #[cfg(feature = "ion-binary")]
            let binary_writer_builder = ion_rs::BinaryWriterBuilder::new();
        #[cfg(feature = "ion-text")]
            let text_writer_builder = ion_rs::TextWriterBuilder::new(TextKind::Compact);

        #[cfg(feature = "ion-binary")]
        #[allow(unused_mut)]
        #[allow(unused_variables)]
            let mut writer = binary_writer_builder.build(buffer.clone()).unwrap();
        #[cfg(feature = "ion-text")]
        #[allow(unused_mut)]
        #[allow(unused_variables)]
            let mut writer = text_writer_builder.build(buffer).unwrap();

        writer.step_in(ion_rs::IonType::Struct).expect("Error while creating an ion struct");

        writer.set_field_name("group_id");
        match &self.group_id {
            Some(id) => writer.write_string(id).unwrap(),
            None => writer.write_null(ion_rs::IonType::String).unwrap(),
        };

        writer.set_field_name("agent_id");
        match &self.agent_id {
            Some(id) => writer.write_string(id).unwrap(),
            None => writer.write_null(ion_rs::IonType::String).unwrap(),
        };

        writer.set_field_name("type");
        writer.write_string(&self.envelope_type).unwrap();

        writer.set_field_name("data");
        writer.write_blob(&self.data).unwrap();

        writer.step_out().unwrap();
        writer.flush().unwrap();

        writer.output().as_slice().to_owned()
    }
}

impl crate::decoder_api::Decoder for Envelope {
    fn decode(data: &[u8]) -> Self {

        let mut binary_user_reader = ion_rs::ReaderBuilder::new().build(data).unwrap();
        binary_user_reader.next().unwrap();
        binary_user_reader.step_in().unwrap();

        let binding;
        binary_user_reader.next().unwrap();
        let group_id = match binary_user_reader.current() {
            ion_rs::StreamItem::Value(_) => {
                binding = binary_user_reader.read_string().unwrap();
                Some(binding.text())
            },
            ion_rs::StreamItem::Null(_) => None,
            //TODO: Return en error here in future
            ion_rs::StreamItem::Nothing => todo!(),
        };

        let binding;
        binary_user_reader.next().unwrap();
        let agent_id = match binary_user_reader.current() {
            ion_rs::StreamItem::Value(_) => {
                binding = binary_user_reader.read_string().unwrap();
                Some(binding.text())
            },
            ion_rs::StreamItem::Null(_) => {
                None
            },
            //TODO: Return en error here in future
            ion_rs::StreamItem::Nothing => todo!(),
        };

        binary_user_reader.next().unwrap();
        let binding = binary_user_reader.read_string().unwrap();
        let envelope_type = binding.text();

        binary_user_reader.next().unwrap();
        let binding = binary_user_reader.read_blob().unwrap();
        let data = binding.as_slice();

        Envelope::new(
            group_id,
            agent_id,
            envelope_type,
            data,
        )
    }
}


#[cfg(test)]
mod tests {
    use ion_rs::IonType;
    use ion_rs::IonReader;
    use ion_rs::ReaderBuilder;
    use ion_rs::StreamItem;

    use crate::decoder_api::Decoder;
    use crate::encoder_api::Encoder;


    use super::Envelope;

    #[test]
    fn test_option_getters() {
        const GROUP_ID: Option<&str> = Some("SOME_GROUP_ID");
        const AGENT_ID: Option<&str> = Some("SOME_AGENT_ID");
        const ENVELOPE_TYPE: &str = "ENVELOPE_TYPE";
        const ENVELOPE_DATA: &[u8] = "ENVELOPE_DATA".as_bytes();
        let mut envelope = Envelope::new(GROUP_ID, AGENT_ID, ENVELOPE_TYPE, ENVELOPE_DATA);

        assert!(envelope.get_agent_id().is_ok());
        assert!(envelope.get_group_id().is_ok());

        envelope.agent_id = None;
        envelope.group_id = None;

        assert!(envelope.get_agent_id().is_err());
        assert!(envelope.get_group_id().is_err());
    }

    #[test]
    fn reader_correctly_read_encoded_envelope() {
        const GROUP_ID: Option<&str> = Some("SOME_GROUP_ID");
        const AGENT_ID: Option<&str> = Some("SOME_AGENT_ID");
        const ENVELOPE_TYPE: &str = "ENVELOPE_TYPE";
        const ENVELOPE_DATA: &[u8] = "ENVELOPE_DATA".as_bytes();
        let envelope = Envelope::new(GROUP_ID, AGENT_ID, ENVELOPE_TYPE, ENVELOPE_DATA);

        let mut binary_user_reader = ReaderBuilder::new().build(envelope.encode()).unwrap();

        assert_eq!(StreamItem::Value(IonType::Struct), binary_user_reader.next().unwrap());
        binary_user_reader.step_in().unwrap();

        assert_eq!(StreamItem::Value(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("group_id", binary_user_reader.field_name().unwrap());
        assert_eq!(GROUP_ID.unwrap(),  binary_user_reader.read_string().unwrap().text());

        assert_eq!(StreamItem::Value(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("agent_id", binary_user_reader.field_name().unwrap());
        assert_eq!(AGENT_ID.unwrap(),  binary_user_reader.read_string().unwrap().text());


        assert_eq!(StreamItem::Value(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("type", binary_user_reader.field_name().unwrap());
        assert_eq!(ENVELOPE_TYPE, binary_user_reader.read_string().unwrap().text());

        assert_eq!(StreamItem::Value(IonType::Blob), binary_user_reader.next().unwrap());
        assert_eq!("data", binary_user_reader.field_name().unwrap());
        assert_eq!(ENVELOPE_DATA, binary_user_reader.read_blob().unwrap().as_slice());
    }

    #[test]
    fn reader_correctly_read_encoded_envelope_with_nones() {
        const ENVELOPE_TYPE: &str = "ENVELOPE_TYPE";
        const ENVELOPE_DATA: &[u8] = "ENVELOPE_DATA".as_bytes();
        let envelope = Envelope::new(None, None, ENVELOPE_TYPE, ENVELOPE_DATA);

        let mut binary_user_reader = ReaderBuilder::new().build(envelope.encode()).unwrap();

        assert_eq!(StreamItem::Value(IonType::Struct), binary_user_reader.next().unwrap());
        binary_user_reader.step_in().unwrap();

        assert_eq!(StreamItem::Null(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("group_id", binary_user_reader.field_name().unwrap());

        assert_eq!(StreamItem::Null(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("agent_id", binary_user_reader.field_name().unwrap());


        assert_eq!(StreamItem::Value(IonType::String), binary_user_reader.next().unwrap());
        assert_eq!("type", binary_user_reader.field_name().unwrap());
        assert_eq!(ENVELOPE_TYPE, binary_user_reader.read_string().unwrap().text());

        assert_eq!(StreamItem::Value(IonType::Blob), binary_user_reader.next().unwrap());
        assert_eq!("data", binary_user_reader.field_name().unwrap());
        assert_eq!(ENVELOPE_DATA, binary_user_reader.read_blob().unwrap().as_slice());
    }

    #[test]
    fn endec_envelope() {
        const GROUP_ID: Option<&str> = Some("SOME_GROUP_ID");
        const AGENT_ID: Option<&str> = Some("SOME_AGENT_ID");
        const ENVELOPE_TYPE: &str = "ENVELOPE_TYPE";
        const ENVELOPE_DATA: &[u8] = "ENVELOPE_DATA".as_bytes();
        let envelope = Envelope::new(GROUP_ID, AGENT_ID, ENVELOPE_TYPE, ENVELOPE_DATA);
        assert_eq!(envelope, Envelope::decode(&envelope.encode()));
    }
}