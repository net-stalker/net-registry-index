pub trait Decoder {
    //TODO: Think of returning Result istread of walue for logs in future
    fn decode(data: &[u8]) -> Self where Self : Sized;
}