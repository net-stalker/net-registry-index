#[allow(clippy::module_inception)]
pub mod envelope;