pub trait Encoder {
    //TODO: Think of returning Result instead of value for logs in future
    fn encode(&self) -> Vec<u8>;
}