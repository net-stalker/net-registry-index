use std::sync::Arc;

use log::debug;

use net_agent_api::api::data_packet::DataPacketDTO;
use net_core::capture::global_header::GlobalHeader;
use net_core::capture::packet::Packet;
use net_core::capture::polling::Handler;
use net_transport::sockets::Sender;
use net_proto_api::encoder_api::Encoder;
use net_proto_api::envelope::envelope::Envelope;

pub struct Codec<S>
where S: Sender + ?Sized
{
    group_id: String,
    agent_id: String,
    
    client: Arc<S>,
}

impl<S> Codec<S>
where S: Sender + ?Sized
{
    pub fn new(group_id: String, agent_id: String, client: Arc<S>) -> Self {
        Self { group_id, agent_id, client }
    }
}

impl<S> Handler for Codec<S>
where S: Sender + ?Sized
{
    fn decode(&self, _cnt: i32, packet: Packet) {
        let global_header = GlobalHeader::default();
        debug!("{:?}", global_header);
        debug!("{:?}", packet);

        //TODO very slow, should be redesigned in the task CU-861maxexc
        let mut buf = global_header.to_bytes();
        buf.append(&mut packet.to_bytes());

        let data_packet_dto = DataPacketDTO::new(&buf);
        let envelope = Envelope::new(Some(&self.group_id), Some(&self.agent_id), "data_packet",&data_packet_dto.encode());
        self.client.send(&envelope.encode());
    }
}