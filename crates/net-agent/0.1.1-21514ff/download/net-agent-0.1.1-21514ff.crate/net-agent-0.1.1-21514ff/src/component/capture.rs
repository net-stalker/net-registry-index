use std::rc::Rc;
use log::info;
use threadpool::ThreadPool;

use net_core::capture;
use net_core::layer::NetComponent;

use net_transport::dummy_command::DummyCommand;
use net_transport::zmq::builders::dealer::ConnectorZmqDealerBuilder;
use net_transport::zmq::contexts::dealer::DealerContext;

use crate::codec::Codec;
use crate::config::Config;

pub struct Capture {
    pool: ThreadPool,
    config: Config,
}

impl Capture {
    pub fn new(pool: ThreadPool, config: Config) -> Self {
        Capture {
            pool,
            config,
        }
    }
}

impl NetComponent for Capture {
    fn run(self) {
        info!("Run component");
        let capture = pcap::Capture::from_device(self.config.capture.device_name.as_str())
            .unwrap()
            // .promisc(true)
            // .snaplen(65535)
            .buffer_size(self.config.capture.buffer_size)
            .open()
            .unwrap();
        let zmq_context = DealerContext::default();
        self.pool.execute(move || {
            let client = ConnectorZmqDealerBuilder::new(&zmq_context)
                .with_endpoint(self.config.agent_connector.addr)
                .with_handler(Rc::new(DummyCommand))
                .build()
                .connect()
                .into_inner();

            let capturing_payload = self.config.capture.capturing_payload;
            let codec = Codec::new(self.config.group_id, self.config.agent_id, client);
            capture::polling::Poller::new(capture)
                .with_packet_cnt(self.config.capture.number_packages)
                .with_codec(codec)
                .with_payload_capture(capturing_payload)
                .poll();
        });
    }
}