use std::rc::Rc;
use log::debug;
use net_transport::sockets::{Handler, Receiver, Sender};

pub struct TranslatorHandler<S>
where
    S: Sender,
{
    consumer: Rc<S>    
}

impl<S> TranslatorHandler<S>
where
    S: Sender,
{
    pub fn new(consumer: Rc<S>) -> Self {
        Self { consumer }
    }
}

impl<S> Handler for TranslatorHandler<S>
where
    S: Sender,
{
    fn handle(&self, receiver: &dyn Receiver, _sender: &dyn Sender) {
        let data = receiver.recv();
        debug!("received from translator {:?}", data);
        self.consumer.send(data.as_slice());
    }
}