use std::rc::Rc;
use log::info;
use net_transport::dummy_command::DummyCommand;
use threadpool::ThreadPool;
use net_core::layer::NetComponent;
use net_transport::zmq::builders::dealer::ConnectorZmqDealerBuilder;
use net_transport::polling::zmq::ZmqPoller;
use net_transport::zmq::contexts::dealer::DealerContext;

use crate::command::agent::AgentHandler;
use crate::command::translator::TranslatorHandler;
use crate::config::Config;

pub struct Hub {
    pool: ThreadPool,
    config: Config,
}

impl Hub {
    pub fn new(pool: ThreadPool, config: Config) -> Self {
        Hub { pool, config }
    }
}

impl NetComponent for Hub {
    fn run(self) {
        info!("run component");
        let context = DealerContext::default();

        self.pool.execute(move || {
            // endpoint for net-inserter (url for net-inserter)
            let inserter_endpoint = ConnectorZmqDealerBuilder::new(&context)
                .with_endpoint(self.config.inserter_endpoint.addr)
                .with_handler(Rc::new(DummyCommand))
                .build()
                .bind()
                .into_inner();
            
            // endpoint for net-translator (url for net-translator)
            let translator_endpoint = ConnectorZmqDealerBuilder::new(&context)
                .with_endpoint(self.config.translator_endpoint.addr)
                .with_handler(Rc::new(TranslatorHandler::new(inserter_endpoint)))
                .build()
                .bind()
                .into_inner();

            let agent_handler = AgentHandler { translator: translator_endpoint.clone() };
            // endpoint for net-agent (url for net-agent)
            let agent_endpoint = ConnectorZmqDealerBuilder::new(&context)
                .with_endpoint(self.config.agent_endpoint.addr)
                .with_handler(Rc::new(agent_handler))
                .build()
                .bind()
                .into_inner();

            ZmqPoller::new()
                .add(agent_endpoint)
                .add(translator_endpoint)
                .poll(-1);
        });
    }
}