use std::rc::Rc;
use log::info;
use threadpool::ThreadPool;
use net_core::layer::NetComponent;
use net_transport::zmq::builders::dealer::ConnectorZmqDealerBuilder;
use net_transport::polling::zmq::ZmqPoller;
use net_transport::zmq::contexts::dealer::DealerContext;

use crate::command::agent::AgentCommand;
use crate::command::translator::TranslatorCommand;
use crate::config::Config;

pub struct Hub {
    pool: ThreadPool,
    config: Config,
}

impl Hub {
    pub fn new(pool: ThreadPool, config: Config) -> Self {
        Hub { pool, config }
    }
}

impl NetComponent for Hub {
    fn run(self) {
        info!("run component");
        let context = DealerContext::default();

        self.pool.execute(move || {
            let translator = ConnectorZmqDealerBuilder::new(&context)
                .with_endpoint(self.config.translator_gateway.addr)
                .with_handler(Rc::new(TranslatorCommand))
                .build()
                .bind()
                .into_inner();

            let agent_command = AgentCommand { translator };

            let agent = ConnectorZmqDealerBuilder::new(&context)
                .with_endpoint(self.config.agent_gateway.addr)
                .with_handler(Rc::new(agent_command))
                .build()
                .bind()
                .into_inner();

            ZmqPoller::new()
                .add(agent)
                .poll(-1);
        });
    }
}